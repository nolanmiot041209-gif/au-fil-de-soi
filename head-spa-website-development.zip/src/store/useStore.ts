import { useState } from 'react';

export interface Appointment {
  id: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  date: string;
  time: string;
  service: string;
  duration: number;
  notes: string;
  createdAt: string;
}

export interface Review {
  id: string;
  name: string;
  comment: string;
  rating: number;
  date: string;
  approved: boolean;
}

export interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  isCustom: boolean;
}

export interface SiteContent {
  heroTitle: string;
  heroSubtitle: string;
  heroButton: string;
  aboutTitle: string;
  aboutText: string;
  phone: string;
  email: string;
  address: string;
  logoSrc: string | null;
  logoAlt: string;
  videoSrc: string | null;
  videoEmbed: string;
  instagramUrl: string;
  facebookUrl: string;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface AdminState {
  isLoggedIn: boolean;
  email: string;
  password: string;
}

const DEFAULT_CONTENT: SiteContent = {
  heroTitle: 'Au fil de soi',
  heroSubtitle: 'Votre sanctuaire de bien-être. Laissez-vous envelopper par nos soins japonais du cuir chevelu, conçus pour vous reconnecter à vous-même.',
  heroButton: 'Prendre rendez-vous',
  aboutTitle: 'L\'art du soin, au rythme de vous',
  aboutText: `Bienvenue dans notre univers dédié à la sérénité et au bien-être profond. Chez "Au fil de soi", nous vous proposons une expérience unique inspirée des rituels japonais du head spa.

Chaque soin est pensé comme un voyage intérieur : détendre le corps, libérer l'esprit, et chouchouter votre cuir chevelu avec des gestes précis et des produits d'exception.

Notre philosophie repose sur trois piliers fondamentaux : la détente, le soin et la reconnexion à soi. Parce que prendre soin de soi n'est pas un luxe, c'est une nécessité.`,
  phone: '+33 6 00 00 00 00',
  email: 'contact@aufildesoi.fr',
  address: '12 Rue de la Sérénité, 75001 Paris',
  logoSrc: null,
  logoAlt: 'Au fil de soi',
  videoSrc: null,
  videoEmbed: '',
  instagramUrl: '#',
  facebookUrl: '#',
};

const DEFAULT_GALLERY: GalleryImage[] = [
  { id: '1', src: '/images/gallery-1.jpg', alt: 'Soin du cuir chevelu', isCustom: false },
  { id: '2', src: '/images/gallery-2.jpg', alt: 'Produits naturels', isCustom: false },
  { id: '3', src: '/images/gallery-3.jpg', alt: 'Espace de détente', isCustom: false },
  { id: '4', src: '/images/gallery-4.jpg', alt: 'Moment de relaxation', isCustom: false },
  { id: '5', src: '/images/gallery-5.jpg', alt: 'Traitement vapeur', isCustom: false },
];

const ADMIN_CREDENTIALS = {
  email: 'admin@aufildesoi.fr',
  password: 'Admin2024!',
};

const TIME_SLOTS = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '12:00', '12:30', '14:00', '14:30', '15:00', '15:30',
  '16:00', '16:30', '17:00', '17:30', '18:00', '18:30',
];

const SERVICES = [
  { id: 's1', name: 'Head Spa Signature', duration: 60, price: '85€', description: 'Notre soin phare : massage crânien profond + soin du cuir chevelu + vapeur.' },
  { id: 's2', name: 'Soin Relaxant Express', duration: 30, price: '45€', description: 'Un moment de détente intense pour les journées chargées.' },
  { id: 's3', name: 'Rituel Sérénité', duration: 90, price: '120€', description: 'L\'expérience ultime : massage + soin + modelage + méditation guidée.' },
  { id: 's4', name: 'Soin Revitalisant', duration: 45, price: '65€', description: 'Stimulation du cuir chevelu avec huiles essentielles japonaises.' },
];

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

// Singleton store using localStorage
export function useAppStore() {
  const [content, setContentState] = useState<SiteContent>(() =>
    loadFromStorage('aufildesoi_content', DEFAULT_CONTENT)
  );
  const [gallery, setGalleryState] = useState<GalleryImage[]>(() =>
    loadFromStorage('aufildesoi_gallery', DEFAULT_GALLERY)
  );
  const [appointments, setAppointmentsState] = useState<Appointment[]>(() =>
    loadFromStorage('aufildesoi_appointments', [])
  );
  const [reviews, setReviewsState] = useState<Review[]>(() =>
    loadFromStorage('aufildesoi_reviews', [])
  );
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() =>
    loadFromStorage('aufildesoi_admin_logged', false)
  );

  const setContent = (updates: Partial<SiteContent>) => {
    setContentState(prev => {
      const next = { ...prev, ...updates };
      saveToStorage('aufildesoi_content', next);
      return next;
    });
  };

  const setGallery = (images: GalleryImage[]) => {
    setGalleryState(images);
    saveToStorage('aufildesoi_gallery', images);
  };

  const addGalleryImage = (image: GalleryImage) => {
    setGalleryState(prev => {
      const next = [...prev, image];
      saveToStorage('aufildesoi_gallery', next);
      return next;
    });
  };

  const removeGalleryImage = (id: string) => {
    setGalleryState(prev => {
      const next = prev.filter(img => img.id !== id);
      saveToStorage('aufildesoi_gallery', next);
      return next;
    });
  };

  const addAppointment = (apt: Appointment) => {
    setAppointmentsState(prev => {
      const next = [...prev, apt];
      saveToStorage('aufildesoi_appointments', next);
      return next;
    });
  };

  const updateAppointment = (id: string, updates: Partial<Appointment>) => {
    setAppointmentsState(prev => {
      const next = prev.map(a => a.id === id ? { ...a, ...updates } : a);
      saveToStorage('aufildesoi_appointments', next);
      return next;
    });
  };

  const deleteAppointment = (id: string) => {
    setAppointmentsState(prev => {
      const next = prev.filter(a => a.id !== id);
      saveToStorage('aufildesoi_appointments', next);
      return next;
    });
  };

  const addReview = (review: Review) => {
    setReviewsState(prev => {
      const next = [...prev, review];
      saveToStorage('aufildesoi_reviews', next);
      return next;
    });
  };

  const updateReview = (id: string, updates: Partial<Review>) => {
    setReviewsState(prev => {
      const next = prev.map(r => r.id === id ? { ...r, ...updates } : r);
      saveToStorage('aufildesoi_reviews', next);
      return next;
    });
  };

  const deleteReview = (id: string) => {
    setReviewsState(prev => {
      const next = prev.filter(r => r.id !== id);
      saveToStorage('aufildesoi_reviews', next);
      return next;
    });
  };

  const loginAdmin = (email: string, password: string): boolean => {
    if (email === ADMIN_CREDENTIALS.email && password === ADMIN_CREDENTIALS.password) {
      setIsAdminLoggedIn(true);
      saveToStorage('aufildesoi_admin_logged', true);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
    saveToStorage('aufildesoi_admin_logged', false);
  };

  const getAvailableSlots = (date: string): string[] => {
    const bookedSlots = appointments
      .filter(a => a.date === date)
      .map(a => a.time);
    return TIME_SLOTS.filter(slot => !bookedSlots.includes(slot));
  };

  const getOccupiedSlots = (date: string): string[] => {
    return appointments
      .filter(a => a.date === date)
      .map(a => a.time);
  };

  return {
    content,
    setContent,
    gallery,
    setGallery,
    addGalleryImage,
    removeGalleryImage,
    appointments,
    addAppointment,
    updateAppointment,
    deleteAppointment,
    reviews,
    addReview,
    updateReview,
    deleteReview,
    isAdminLoggedIn,
    loginAdmin,
    logoutAdmin,
    getAvailableSlots,
    getOccupiedSlots,
    TIME_SLOTS,
    SERVICES,
  };
}
